The numbers reported in the text documents correspond to the mean (AVG) and median (MED) after
0.1xMaxFES	0.2xMaxFES	0.3xMaxFES	0.4xMaxFES	0.5xMaxFES	0.6xMaxFES	0.7xMaxFES	0.8xMaxFES	0.9xMaxFES	MaxFES
function evaluations.