function f = sphere(x)
    f = sum(x.*x);
end